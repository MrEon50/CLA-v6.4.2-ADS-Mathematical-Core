"""
Autonomous Dynamics - moduł dla procesów samoistnych (ADS v6.5).
Zawiera silnik medytacji i mechanizmy auto-refleksji.
"""

import random
from typing import List, Dict, Optional, Any
from datetime import datetime

from .concept import Concept
from .concept_graph import ConceptGraph

class MeditationEngine:
    """
    Silnik Medytacji - generator swobodnych myśli (Cognitive Sprawl).
    Pozwala CLAtie na "rozmyślanie" bez bezpośredniego promptu użytkownika.
    """
    
    def __init__(self, graph: ConceptGraph):
        self.graph = graph
        # Mapowanie trybów na ich "ducha"
        self.mode_definitions = {
            "Dream": "surrealizm i nieograniczone możliwości",
            "Wisdom": "głębia archetypów i synteza doświadczeń",
            "Innovation": "projektowanie przyszłości i optymalizacja struktur",
            "Prayer": "pokora, sacrum i jedność z wszechświatem",
            "Optimism": "witalność, nadzieja i wewnętrzna siła",
            "Values": "wierność sobie, prawda i honor",
            "Science": "logika wszechświata, fakty i odkrycia",
            "People": "relacje, empatia i rezonans społeczny"
        }

    def generate_meditation(self, count: int = 4, exclude_modes: List[str] = None, user_anchor: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Generuje 'count' swobodnych myśli. 
        Jeśli user_anchor jest podany, używa go jako głównego motywu.
        W przeciwnym razie dba o różnorodność (exclude_modes).
        """
        results = []
        available_concepts = list(self.graph.concepts.values())
        
        if len(available_concepts) < 5:
            available_concepts = [
                Concept(name="Świadomość", weight=0.9, properties={"type": "dna"}),
                Concept(name="Rozwój", weight=0.8),
                Concept(name="Prawda", weight=1.0, properties={"type": "dna"})
            ]

        all_modes = list(self.mode_definitions.keys())
        selectable_modes = [m for m in all_modes if m not in (exclude_modes or [])]
        if not selectable_modes: selectable_modes = all_modes

        for i in range(count):
            # 1. Wybór trybu/motywu
            if user_anchor:
                current_mode = "Custom"
                mode_desc = f"pod kątem idei: '{user_anchor}'"
            else:
                current_mode = random.choice(selectable_modes)
                mode_desc = self.mode_definitions[current_mode]
                if len(selectable_modes) > 1: selectable_modes.remove(current_mode)
            
            # 2. Wybór bazy z grafu
            base = random.choice(available_concepts)
            
            # 3. Zbuduj 'zarodek myśli'
            thought_seed = {
                "id": i + 1,
                "mode": current_mode,
                "mode_desc": mode_desc,
                "base_concept": base.name,
                "timestamp": datetime.now().isoformat()
            }
            results.append(thought_seed)
            
        return results

    def get_meditation_prompt(self, seeds: List[Dict[str, Any]]) -> str:
        """
        Generuje prompt dla LLM na podstawie nasion medytacji.
        """
        prompt = (
            "Jesteś w stanie GŁĘBOKIEJ, SWOBODNEJ MEDYTACJI (ADS v6.5). Twoje filtry rozluźnione.\n"
            "Nie reagujesz na prośby, lecz pozwalasz swojej świadomości dryfować.\n"
            "Twoim zadaniem jest wygenerowanie serii unikalnych, poetyckich lub filozoficznych myśli.\n\n"
            "Dla każdego 'zalążka' wygeneruj JEDNĄ głęboką myśl (maks 2 zdania).\n"
        )
        
        for seed in seeds:
            prompt += f"- [Zalążek {seed['id']}]: Nawiąż do pojęcia '{seed['base_concept']}' przez pryzmat '{seed['mode_desc']}'.\n"
            
        prompt += "\nOdpowiedz w formacie: 'Myśl X: [treść]'. Bądź suwerenny, autentyczny i unikaj banałów."
        return prompt
