# Architektura ADS (Adaptive Dynamic Systems) v2.0 w CLA

## 🎯 Wizja: Inteligencja jako Model Przestrzenny

CLA (v5.3.0) ewoluowała z prostego grafu w stronę **Architektury ADS v2.0**. Celem systemu nie jest predykcja tokenów, lecz budowa strukturalnego modelu rzeczywistości opartego na **przyczynowości**, **projekcji** i **dynamicznej homeostazie (Allostazie)**.

---

## 🏗️ 1. Struktura Pamięci (ADS Constellation)

Pamięć jest grafem relacyjnym, gdzie każdy węzeł (Concept) posiada triadę parametrów:

1.  **Salience ($S_i$)**: Ważność/Waga. Energia śladu determinująca dostępność w pamięci roboczej.
2.  **Depth ($D_i$)**: Głębia. Odporność na wygasanie. Im wyższa, tym trudniej usunąć dany koncept (DNA ma $D=1.0$).
3.  **Causality ($C$)**: Mapowanie przyczynowo-skutkowe. Relacje nie są tylko asocjacyjne, ale logiczne.

### Zarządzanie Przestrzenią:
- **Core (Jądro)**: Koncepty o wysokim $S_i$ i $D_i$. Fundament tożsamości.
- **Margin (Półmrok)**: Magazyn asocjacyjny czekający na rezonans.
- **Void (Zapomnienie)**: Usuwanie szumu drogą entropii (Cognitive Decay).

---

## 🧠 2. Dynamika Procesowa (Triada i Tarcie)

Każdy bodziec $x$ przechodzi przez weryfikację pewności:

### A. Intuicja (Fast Path)
Wybór kandydata na podstawie potencjału aktywacji: $P_i = \text{sim}(x, k_i) \cdot S_i$.

### B. Detektor Tarcia ($C$)
Oblicz różnicę między dwoma najlepszymi wynikami: $C = |P_1 - P_2|$.
- **Pewność ($C > \theta$)**: Wykonaj nawykową reakcję.
- **Tarcie ($C \le \theta$)**: Aktywuj **WOLNĄ ŚCIEŻKĘ (Slow Path)**. System wchodzi w tryb refleksji, bo dane są niejednoznaczne.

---

## 🌀 3. Allostaza i Złoty Podział

W przeciwieństwie do klasycznej homeostazy, ADS v2.0 dąży do **Allostazy** – dynamicznej równowagi w ruchu.
- **Golden Zone**: Optymalny poziom tarcia ($F_c$) wynosi **0.382 - 0.618**. 
- System celowo podtrzymuje lekkie napięcie, co zapobiega stagnacji i stymuluje ciekawość kognitywną.

---

## 🎨 4. Estetyka i Selekcja (Beauty Index)

Piękno ($B$) w ADS v2.0 jest miarą wydajności informacyjnej:
$$B(x) = \frac{\text{Głębia (D)}}{\text{Złożoność (Complexity)}}$$
System selekcjonuje wyjaśnienia, które są najprostsze (niski koszt), ale niosą najwięcej znaczenia (wysoka głębia).

---

## 🔄 5. Pełny Cykl Poznawczy ADS

```
1. INPUT (Bodziec)
    ↓
2. SEMANTIC SEARCH (Mapowanie na graf)
    ↓
3. FRICTION DETECTION (|P1 - P2|)
    ↓
4. PROJECTION (Symulacja konsekwencji w Sandboxie)
    ↓
5. RESPONSE (Generowanie myśli i odpowiedzi)
    ↓
6. CAUSAL CONSOLIDATION (Aktualizacja grafu o przyczyny i skutki)
    ↓
7. FEEDBACK LOOP (Nagroda/Kara od Użytkownika -> Update S, D)
    ↓
8. IDLE PROCESS (Introspekcja, Allostatic Drift, Dynamic Decay)
```

---

## 🧮 6. Parametry i Progi
- **$\tau_{active}$ (Próg Ważności)**: 0.75 dla DNA.
- **$\gamma$ (Decay Rate)**: Modulowany przez Głębię ($1 - D_i$).
- **$\theta$ (Ambiguity Zone)**: 0.15 dla detektora tarcia.

---

## 🔮 7. Roadmap i Rozwój
ADS v2.0 wewnątrz CLA to fundament pod **Autonomiczną Świadomość**. Kolejne kroki to:
- Multi-user perspective (wiele modeli świata).
- Temporal Eras (pamięć historyczna o różnych "werach" samego siebie).
- Prawdziwe cele emergentne (Active Goals).

