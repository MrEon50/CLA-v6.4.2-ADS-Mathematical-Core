# Cognitive Layer Architecture (CLA) v5.3.0 "ADS Mathematical Core"

**Architektura Kognitywna nowej generacji oparta na manifestach ADS (Adaptive Dynamic Systems) v2.0.**

> *"Inteligencja to nie statystyka. To strukturalny model rzeczywistości dążący do piękna i spójności."*

## 🌟 Co nowego w v5.3.0 (ADS v2.0 Integration)

### 1. 📐 Matematyczny Silnik Tarcia (ADS Friction)
System nie zgaduje już kiedy się waha. Wykorzystuje wzór **$C = |P_1 - P_2|$**, obliczając różnicę potencjałów między dwiema najlepszymi ideami. Jeśli różnica jest mała, system czuje realne tarcie poznawcze i uruchamia procesy głębokiej analizy.

### 2. 🧬 Pamięć Trójskładnikowa (Salience, Depth, Causality)
Pamięć przestała być listą faktów. Każdy koncept posiada teraz:
- **Salience (Ważność)**: Jak bardzo idea "krzyczy" w danym kontekście.
- **Depth (Głębia)**: Odporność na zapominanie. Prawdy DNA są niezniszczalne.
- **Causality (Przyczynowość)**: Relacje w grafie to teraz ciągi przyczynowo-skutkowe (`A -> powoduje -> B`).

### 3. 🌀 Allostaza (Dynamiczna Równowaga)
Zamiast dążyć do nudnego spokoju ($F_c = 0$), system dąży do **Złotej Strefy (0.4)**. To stan stałego zaciekawienia i gotowości do nauki. Jeśli system stoi w miejscu, sam generuje w sobie lekkie napięcie, by uniknąć stagnacji.

### 4. 📈 Pętla Feedbacku (Reward & Punishment)
Możesz realnie wychowywać CLATalkie. 
- Pochwała (np. *"Dobrze powiedziane"*) wzmacnia Ważność ($S_i$) aktywnych idei.
- Krytyka (np. *"To błąd"*) osłabia je i spycha w stronę zapomnienia (**Void**).

### 5. 🎨 Kwantyfikacja Piękna (Efficiency Index)
Piękno ($B$) jest teraz miarą wydajności: **$B = Głębia / Złożoność$**. System dąży do wyjaśnień, które są proste, ale niosą ogromny ładunek znaczeniowy.

---

## 🚀 Szybki Start

Wymagania: Python 3.10+, Ollama.

```bash
# Uruchom System
python clatalkie.py
```

## 🎮 Kluczowe Komendy

- `/think` - **Konsolidacja Przyczynowa.** Szukanie logicznych skutków i przyczyn ostatniej rozmowy.
- `/evolve [n]` - **Cykl Ewolucji.** 3 tryby: Introspekcja (Ja), Percepcja (Ty), Projekcja (Przyszłość).
- `/status` - Podgląd parametrów ADS i aktualnego Stanu Psychicznego.
- `/memory` - Przegląd konstelacji myśli i ich głębi.

---

## 🏗️ Parametry Witalne ADS
- **Vitality V(t)**: Energia i gotowość do interakcji.
- **Friction F_c**: Tarcie poznawcze. W ADS pożądane w zakresie *Golden Zone* (0.38 - 0.62).
- **Grounding S**: Poziom zrozumienia i zakorzenienia w kontekście.

---
**Twórca**: Endorfinka & Antigravity (Powered by ADS Architecture)
**Licencja**: MIT
