# Quick Start Guide - CLA

## 🚀 Instalacja (30 sekund)

```bash
# 1. Klonuj repo
git clone <repo-url>
cd CLA

# 2. Zainstaluj zależności
pip install -r requirements.txt

# 3. Gotowe!
```

## 💡 Pierwsze Kroki (5 minut)

### 1. Uruchom Demonstrację

```bash
python examples/demo_cognitive_layer.py
```

Zobaczysz:
- ✅ Syntezę poznawczą (GLOBAL ↔ LOCAL → HIERARCHICAL_REASONING)
- ✅ Syntezę emocjonalną (LOVE ↔ HATE → AMBIVALENCE)
- ✅ Syntezę moralną (UNIVERSAL ↔ CONTEXTUAL → CONTEXTUAL_ETHICS)
- ✅ Pełny cykl z feedbackiem

### 2. Uruchom Testy

```bash
python tests/test_dual_processing.py
```

Wszystkie 4 testy powinny przejść ✅

### 3. Zobacz Wizualizację

```bash
python examples/visualize_synthesis.py
```

Krok po kroku proces syntezy poznawczej.

### 4. Przykłady API

```bash
python examples/api_examples.py
```

5 przykładów użycia API.

## 📝 Podstawowe Użycie

```python
from cla.core import CognitiveLayer
import numpy as np

# Stwórz system
cla = CognitiveLayer(identity="My AI")

# Zdefiniuj koncepty w dualności
concepts = [
    {
        'name': 'FAST',
        'embedding': np.array([1.0, 0.0, 0.0, 0.0]),
        'activation': 0.8,
        'duality_category': 'cognitive',
        'properties': {'speed': 'high'}
    },
    {
        'name': 'SLOW',
        'embedding': np.array([-1.0, 0.0, 0.0, 0.0]),
        'activation': 0.8,
        'duality_category': 'cognitive',
        'properties': {'speed': 'low'}
    }
]

# Przetwórz
result = cla.process(concepts, context="Need balance")

# Wynik
if result['status'] == 'success':
    print(f"Synteza: {result['synthesis']['new_concept']}")
    print(f"Reasoning: {result['synthesis']['reasoning']}")
```

## 🧠 Kluczowe Koncepty

### Dualność
Dwa przeciwstawne koncepty (np. GLOBAL ↔ LOCAL)

### Tarcie Poznawcze
Napięcie między biegunami dualności:
```
friction = activation_A × activation_B × opposition
```

### Synteza
Nowy koncept emergentny z tarcia:
- **Integration**: Łączy oba bieguny
- **Transcendence**: Przekracza dualność
- **Balance**: Balansuje między biegunami

### Kategorie
- **Cognitive**: GLOBAL ↔ LOCAL, ANALYTICAL ↔ INTUITIVE
- **Emotional**: LOVE ↔ HATE, FEAR ↔ CALM
- **Moral**: UNIVERSAL ↔ CONTEXTUAL, TRUTH ↔ LOYALTY

## 🎯 Typowe Scenariusze

### Scenariusz 1: Dylemat Decyzyjny
```python
# Mam dwa sprzeczne cele
concepts = [
    {'name': 'SPEED', ...},  # Chcę szybko
    {'name': 'QUALITY', ...}  # Chcę dobrze
]

result = cla.process(concepts, "Project deadline approaching")
# → Synteza: ADAPTIVE_QUALITY (priorytetyzuj krytyczne elementy)
```

### Scenariusz 2: Konflikt Emocjonalny
```python
# Sprzeczne emocje
concepts = [
    {'name': 'LOVE', ...},   # Kocham tę osobę
    {'name': 'ANGER', ...}   # Ale jestem zły
]

result = cla.process(concepts, "Relationship conflict")
# → Synteza: AMBIVALENCE (zaakceptuj złożoność)
```

### Scenariusz 3: Dylemat Etyczny
```python
# Sprzeczne wartości
concepts = [
    {'name': 'HONESTY', ...},  # Powinienem powiedzieć prawdę
    {'name': 'KINDNESS', ...}  # Ale to kogoś zrani
]

result = cla.process(concepts, "Should I tell harsh truth?")
# → Synteza: COMPASSIONATE_HONESTY (prawda z empatią)
```

## 🔍 Introspection API

```python
# System może odpowiadać na pytania o siebie
print(cla.awareness.introspect('who_am_i'))
# → "I am My AI, a cognitive system..."

print(cla.awareness.introspect('what_do_i_know'))
# → "I know 5 concepts: FAST, SLOW, ..."

print(cla.awareness.introspect('how_do_i_feel'))
# → "I feel neutral, confident, and relaxed."
```

## 📊 Monitoring

```python
# Sprawdź status systemu
status = cla.get_status()

print(f"Koncepty: {status['concept_graph']['total_concepts']}")
print(f"Interakcje: {status['interactions']}")
print(f"Shared grounding: {status['safety']['shared_grounding']}")
```

## 🔄 Feedback Loop

```python
# System uczy się z feedbacku
result = cla.process(concepts, context)

# Pozytywny feedback
cla.learn_from_feedback({
    'decision': result['synthesis']['new_concept'],
    'outcome': 'success',
    'context': context,
    'shared_grounding': 0.9
})

# System aktualizuje shared grounding i success rate
```

## 📚 Dalsze Kroki

1. **Przeczytaj README.md** - Filozofia i esencja
2. **Przeczytaj ARCHITECTURE.md** - Szczegóły techniczne
3. **Przeczytaj RESULTS.md** - Wyniki i wnioski
4. **Eksperymentuj** - Stwórz własne dualności!

## 🆘 Troubleshooting

### Problem: ModuleNotFoundError
```bash
# Upewnij się że jesteś w głównym katalogu
cd CLA
python examples/demo_cognitive_layer.py
```

### Problem: Brak syntezy
```python
# Sprawdź czy friction > 0.3
# Zwiększ activation konceptów (> 0.5)
# Upewnij się że embeddingi są przeciwstawne
```

### Problem: Niska pewność
```python
# To normalne dla nowych konceptów
# System zwiększa pewność z feedbackiem
# Sprawdź shared_grounding (powinno być ≥ 0.8)
```

## 🎉 Gotowe!

Teraz możesz:
- ✅ Tworzyć emergentne koncepty
- ✅ Rozwiązywać dylematy
- ✅ Monitorować świadomość systemu
- ✅ Uczyć system przez feedback

**Miłej zabawy z CLA!** 🧠✨

