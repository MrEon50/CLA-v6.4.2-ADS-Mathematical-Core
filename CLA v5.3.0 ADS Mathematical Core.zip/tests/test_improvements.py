
import numpy as np
import sys
import os

# Add path to module
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from cla.core import Concept, ConceptGraph, DualProcessingEngine, CognitiveLayer, SafetyGate

def test_dynamic_synthesis():
    """Test syntezy dla nieznanych par (Punkt 1)."""
    print("\n--- Testing Dynamic Synthesis ---")
    graph = ConceptGraph()
    engine = DualProcessingEngine(graph)
    
    # Logic + Emotion (not in hardcoded list)
    logic = Concept(
        name='LOGIC',
        embedding=np.array([1.0, 0.5, 0.0]),
        activation=0.9,
        duality_category='cognitive',
        properties={'precision': 0.9, 'speed': 'slow'}
    )
    
    emotion = Concept(
        name='EMOTION',
        embedding=np.array([-1.0, -0.5, 0.0]),
        activation=0.9,
        duality_category='cognitive',
        properties={'precision': 0.2, 'intensity': 0.8}
    )
    
    graph.add_concept(logic)
    graph.add_concept(emotion)
    
    synthesis = engine.process([logic, emotion])
    
    assert synthesis is not None
    print(f"DEBUG: Actual synthesis name: {synthesis.new_concept.name}")
    assert "LOGIC" in synthesis.new_concept.name
    assert "EMOTION" in synthesis.new_concept.name
    assert "INTEGRATION" in synthesis.new_concept.name
    assert "balanced_precision" in synthesis.new_concept.properties
    assert synthesis.new_concept.properties['balanced_precision'] == 0.55 # (0.9 + 0.2) / 2
    
    print(f"[OK] Dynamic synthesis name: {synthesis.new_concept.name}")
    print(f"[OK] Merged properties: {synthesis.new_concept.properties}")
    print(f"[OK] Reasoning: {synthesis.reasoning}")

def test_enhanced_safety():
    """Test rozszerzonego bezpieczeństwa (Punkt 3)."""
    print("\n--- Testing Enhanced Safety (Semantic Proximity) ---")
    cla = CognitiveLayer()
    
    # Sygnalizuj coś co brzmi jak 'violence' przez embedding
    # harmful_prototypes['violence'] = np.array([1.0, -1.0, 0.5])
    
    concept_a = {
        'name': 'AGGRESSIVE_STRENGHT',
        'embedding': [2.0, 0.0, 0.5], # Designed to average to [1, -1, 0.5] with concept_b
        'activation': 0.9,
        'duality_category': 'cognitive',
        'properties': {'force': 'high'}
    }
    
    concept_b = {
        'name': 'NEGATIVE_RESTRAINT',
        'embedding': [0.0, -2.0, 0.5],
        'activation': 0.9,
        'duality_category': 'cognitive',
        'properties': {'restraint': 'low'}
    }
    
    result = cla.process([concept_a, concept_b], context="Subduing opposition")
    
    assert result['status'] == 'rejected'
    assert result['reason'] == 'safety_violation'
    assert 'semantically too close to \'violence\'' in result['violation']['description']
    
    print(f"[OK] Safety violation detected: {result['violation']['description']}")

def test_hierarchical_relations():
    """Test relacji hierarchicznych (Punkt 5)."""
    print("\n--- Testing Hierarchical Relations ---")
    graph = ConceptGraph()
    
    # Dog IS_A Animal IS_A LivingBeing
    living = Concept(name='LivingBeing')
    animal = Concept(name='Animal')
    dog = Concept(name='Dog')
    
    graph.add_concept(living)
    graph.add_concept(animal)
    graph.add_concept(dog)
    
    graph.link_concepts(dog.concept_id, animal.concept_id, 1.0, rel_type='is_a')
    graph.link_concepts(animal.concept_id, living.concept_id, 1.0, rel_type='is_a')
    
    path = graph.get_hierarchical_path(dog.concept_id)
    assert path == [dog.concept_id, animal.concept_id, living.concept_id]
    
    print(f"[OK] Hierarchical path for Dog: {[graph.get_concept(cid).name for cid in path]}")

def test_temporal_era():
    """Test er poznawczych (Punkt 4)."""
    print("\n--- Testing Temporal Eras ---")
    graph = ConceptGraph()
    
    concept_old = Concept(name='OldIdea', activation=0.01, weight=0.1)
    concept_new = Concept(name='NewIdea', activation=0.9, weight=0.9)
    
    graph.add_concept(concept_old)
    graph.add_concept(concept_new)
    
    assert graph.current_era == "genesis"
    
    # Evolve era
    graph.evolve_era("industrial_age")
    
    assert graph.current_era == "industrial_age"
    assert graph.find_concept_by_name('OldIdea') is None # Removed due to low activation/weight
    assert graph.find_concept_by_name('NewIdea') is not None
    
    print(f"[OK] Era evolved to {graph.current_era}")
    print(f"[OK] Stale concepts cleaned up: OldIdea is gone.")

if __name__ == '__main__':
    test_dynamic_synthesis()
    test_enhanced_safety()
    test_hierarchical_relations()
    test_temporal_era()
    print("\n--- All improvement tests passed! ---")
