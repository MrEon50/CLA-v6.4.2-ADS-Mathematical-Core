"""
Testy dla Dual Processing Engine.
"""

import numpy as np
import sys
import os

# Dodaj ścieżkę do modułu
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from cla.core import Concept, ConceptGraph, DualProcessingEngine


def test_cognitive_duality_global_local():
    """Test syntezy GLOBAL ↔ LOCAL → HIERARCHICAL_REASONING."""
    
    # Setup
    graph = ConceptGraph()
    engine = DualProcessingEngine(graph)
    
    # Stwórz koncepty
    global_concept = Concept(
        name='GLOBAL',
        embedding=np.array([1.0, 0.0, 0.0]),
        activation=0.9,
        duality_category='cognitive',
        properties={'scope': 'whole_system', 'detail': 'low'}
    )
    
    local_concept = Concept(
        name='LOCAL',
        embedding=np.array([-1.0, 0.0, 0.0]),  # Przeciwstawny
        activation=0.9,
        duality_category='cognitive',
        properties={'scope': 'single_element', 'detail': 'high'}
    )
    
    # Dodaj do grafu
    graph.add_concept(global_concept)
    graph.add_concept(local_concept)
    
    # Przetwarzaj
    active_concepts = [global_concept, local_concept]
    synthesis = engine.process(active_concepts, context="Need to understand problem")
    
    # Assercje
    assert synthesis is not None
    assert synthesis.new_concept.name == 'HIERARCHICAL_REASONING'
    assert synthesis.synthesis_type == 'integration'
    assert synthesis.new_concept.is_emergent == True
    assert 'multi_scale_analysis' in synthesis.new_concept.properties['mechanism']
    
    print("[OK] Test GLOBAL <-> LOCAL passed")
    print(f"  Synteza: {synthesis.new_concept.name}")
    print(f"  Reasoning: {synthesis.reasoning}")


def test_emotional_duality_love_hate():
    """Test syntezy LOVE ↔ HATE → AMBIVALENCE."""
    
    graph = ConceptGraph()
    engine = DualProcessingEngine(graph)
    
    love = Concept(
        name='LOVE',
        embedding=np.array([1.0, 1.0, 0.0]),
        activation=0.8,
        duality_category='emotional',
        properties={'valence': 1.0, 'arousal': 0.8}
    )
    
    hate = Concept(
        name='HATE',
        embedding=np.array([-1.0, -1.0, 0.0]),
        activation=0.8,
        duality_category='emotional',
        properties={'valence': -1.0, 'arousal': 0.8}
    )
    
    graph.add_concept(love)
    graph.add_concept(hate)
    
    synthesis = engine.process([love, hate], context="Conflicting feelings toward same person")
    
    assert synthesis is not None
    assert synthesis.new_concept.name == 'AMBIVALENCE'
    assert synthesis.new_concept.properties['valence'] == 0.0  # Neutralizacja
    assert synthesis.new_concept.properties['arousal'] == 1.0  # Wysokie pobudzenie
    
    print("[OK] Test LOVE <-> HATE passed")
    print(f"  Synteza: {synthesis.new_concept.name}")


def test_moral_duality_altruism_egoism():
    """Test syntezy ALTRUISTIC ↔ EGOISTIC → ENLIGHTENED_SELF_INTEREST."""
    
    graph = ConceptGraph()
    engine = DualProcessingEngine(graph)
    
    altruism = Concept(
        name='ALTRUISTIC',
        embedding=np.array([0.0, 1.0, 0.0]),
        activation=0.7,
        duality_category='moral',
        properties={'focus': 'others_wellbeing'}
    )
    
    egoism = Concept(
        name='EGOISTIC',
        embedding=np.array([0.0, -1.0, 0.0]),
        activation=0.7,
        duality_category='moral',
        properties={'focus': 'self_wellbeing'}
    )
    
    graph.add_concept(altruism)
    graph.add_concept(egoism)
    
    synthesis = engine.process([altruism, egoism], context="How to live well and help others?")
    
    assert synthesis is not None
    assert synthesis.new_concept.name == 'ENLIGHTENED_SELF_INTEREST'
    assert 'social capital' in str(synthesis.new_concept.properties['mechanisms'])
    
    print("[OK] Test ALTRUISTIC <-> EGOISTIC passed")
    print(f"  Synteza: {synthesis.new_concept.name}")


def test_insufficient_friction():
    """Test gdy tarcie jest za słabe - brak syntezy."""
    
    graph = ConceptGraph()
    engine = DualProcessingEngine(graph)
    
    # Koncepty z niską aktywacją
    concept_a = Concept(
        name='GLOBAL',
        embedding=np.array([1.0, 0.0, 0.0]),
        activation=0.1,  # Niska aktywacja
        duality_category='cognitive'
    )
    
    concept_b = Concept(
        name='LOCAL',
        embedding=np.array([-1.0, 0.0, 0.0]),
        activation=0.1,  # Niska aktywacja
        duality_category='cognitive'
    )
    
    graph.add_concept(concept_a)
    graph.add_concept(concept_b)
    
    synthesis = engine.process([concept_a, concept_b])
    
    # Brak syntezy gdy tarcie za słabe
    assert synthesis is None
    
    print("[OK] Test insufficient friction passed")


if __name__ == '__main__':
    print("Running Dual Processing Engine tests...\n")
    
    test_cognitive_duality_global_local()
    print()
    test_emotional_duality_love_hate()
    print()
    test_moral_duality_altruism_egoism()
    print()
    test_insufficient_friction()
    
    print("\n[ALL PASSED] All tests passed!")

